# 1Fi Marketplace Mobile Interface Design

## Product direction

This prototype extends the existing 1Fi Shop experience with a simple three-option entry point: **Top Brands**, **Nearby Stores**, and **1Fi Marketplace**. The first two destinations are intentionally blank placeholders, while the Marketplace is a polished, locally rendered prototype that demonstrates discovery, browsing, filtering, product details, cart state, and a clear purchase-intent flow without connecting to a real checkout or payment service.

The design assumes mobile portrait orientation and one-handed use. It favors large touch targets, short labels, strong hierarchy, calm spacing, and predictable back navigation. The visual language should feel like a native 1Fi feature rather than a separate e-commerce website.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Shop | Header, short supporting copy, and three large destination options: Top Brands, Nearby Stores, and 1Fi Marketplace. Tapping each option navigates to its destination. |
| Top Brands | Intentional blank state with title, back navigation, and a restrained “Coming soon” treatment. No brand implementation is required. |
| Nearby Stores | Intentional blank state with title, back navigation, and a restrained “Coming soon” treatment. No store implementation is required. |
| 1Fi Marketplace | Marketplace header, search field, category chips, promotional banner, featured product grid/list, and cart affordance. |
| Marketplace Product Detail | Product image area, title, short description, price, merchant or delivery note, quantity controls, and Add to cart CTA. |
| Cart | Selected items, quantity controls, subtotal, and a disabled or prototype checkout CTA with clear local-demo labeling if no backend is connected. |

## Key user flows

### Shop to Marketplace

User opens Shop → taps **1Fi Marketplace** → sees marketplace header and product discovery content → optionally searches or selects a category → taps a product → reviews product detail → taps **Add to cart** → sees cart count update and can open Cart.

### Shop placeholders

User opens Shop → taps **Top Brands** or **Nearby Stores** → sees an intentionally blank “Coming soon” state → taps back to return to Shop.

### Product discovery

User enters a search term → product list filters locally by product name, category, or merchant → user clears search or changes a category chip → list updates without leaving the page.

## Content model

Products should use a shared local type with stable IDs, title, category, price, image or visual placeholder, merchant label, rating, and short description. Cart state should be local React state or AsyncStorage only for this prototype; no authentication, cloud sync, or payment processing is required by the assignment.

## Visual design

Use 1Fi-inspired white surfaces, a restrained deep navy/ink text color, soft neutral backgrounds, and a bright green accent for primary actions and active states. Use rounded rectangles sparingly for product surfaces and controls, with subtle borders rather than heavy shadows. The Shop destination tiles should use a clear icon, title, and supporting line, with the Marketplace tile receiving the strongest accent treatment.

Recommended brand tokens:

| Token | Value | Usage |
|---|---|---|
| Canvas | `#F7F8FA` | Screen background |
| Surface | `#FFFFFF` | Cards, search field, product tiles |
| Ink | `#111827` | Headings and primary text |
| Muted | `#6B7280` | Supporting text and metadata |
| Accent green | `#20B15A` | Primary CTA, active chip, marketplace emphasis |
| Soft green | `#E9F8EF` | Marketplace tile background and promo surface |
| Border | `#E5E7EB` | Dividers and input outlines |

## Interaction and accessibility

All primary tiles and buttons should have at least a 44-point touch target. Use visible press feedback, concise labels, and accessible text alternatives for icons. Search should use a clear keyboard return action. The back action should be available both from the native navigation header and a visible top-left control where appropriate. Product cards should expose title and price together so screen-reader users can understand the selection without relying on imagery.

## Technical constraints

Use `ScreenContainer` for every screen. Use `FlatList` for product lists. Keep the assignment implementation local and deterministic, with no invented live inventory numbers or payment states. Use Expo Router for navigation and keep data types shared between Marketplace list, detail, and cart screens. The Android prototype should remain usable on web preview for visual verification.
