# 1Fi Marketplace Assignment

This repository contains an Expo / React Native prototype of the **1Fi Shop** experience. It is built for the SDE Intern assignment and provides the three requested Shop destinations:

1. **Top Brands** — navigable placeholder page; no catalogue implementation is required.
2. **Nearby Stores** — navigable placeholder page; no catalogue implementation is required.
3. **1Fi Marketplace** — a complete local shopping flow, including discovery, product details, EMI-plan selection, and a local cart.

The prototype is intentionally self-contained. It does not require login, a backend, payment processing, or live inventory to demonstrate the requested product flow.

## Assignment coverage

| Assignment requirement | Implementation |
| --- | --- |
| Three options on Shop | Dedicated, touch-friendly tiles for Top Brands, Nearby Stores, and 1Fi Marketplace. |
| Top Brands / Nearby Stores | Both routes navigate to a deliberately minimal “Coming soon” placeholder. |
| Marketplace implementation | A locally rendered catalogue with categories, search, product detail, EMI selection, and cart state. |
| Product discovery | Search matches title, category, and merchant; category chips filter the catalogue without navigation. |
| Product information | Each item includes a title, price, comparison price, merchant, description, image, variants, and EMI plans. |
| Cart interaction | Add items from a selected plan, update quantities, remove items, view cart badge, and see a subtotal. |
| Robust UI states | Loading, empty-search, empty-cart, and retryable data-error states are included. |

## Feature overview

### Shop landing page

- Clear three-option entry point matching the requested Shop structure.
- Visual emphasis on the Marketplace option.
- Consistent 1Fi-inspired palette: light canvas, deep ink text, purple brand accent, and green success/selection accent.
- Haptic press feedback on native mobile platforms.

### 1Fi Marketplace

- Responsive two-column product grid.
- Search input with a clear action.
- Horizontally scrollable category filters.
- Promotional introduction card explaining the product-to-EMI journey.
- Local mock catalogue with deterministic data; no external API is required for the application state.
- Loading and recoverable failure states around catalogue loading.

### Product detail

- Large product visual, merchant, current price, comparison price, and description.
- Selectable product attributes such as colour, storage, finish, or size.
- Selectable EMI plans with monthly payment and term.
- Summary of the selected EMI plan before the user continues.
- “Proceed with selected plan” adds the product to the local cart and opens it.

### Cart

- Cart badge displays the total item quantity.
- Increase and decrease item quantity controls.
- Remove individual products.
- Live subtotal calculated from local cart state.
- Explicit prototype disclaimer: checkout, eligibility confirmation, and final terms are not simulated.

## User journey

```text
Shop
 ├─ Top Brands       → Placeholder / Coming soon
 ├─ Nearby Stores    → Placeholder / Coming soon
 └─ 1Fi Marketplace
      ├─ Search or choose a category
      ├─ Open a product
      ├─ Choose variant and EMI plan
      └─ Add to cart → Change quantity / remove item / review subtotal
```

## Project structure

```text
app/
  (tabs)/index.tsx          Main Shop, Marketplace, detail, cart, and placeholder views
  _layout.tsx               Expo Router application layout
components/
  screen-container.tsx      Shared screen/safe-area wrapper
lib/
  marketplace-data.ts       Shared product, variant, category, and EMI-plan mock data
tests/
  marketplace-data.test.ts  Catalogue data validation tests
assets/                     Application icons and Expo image assets
```

The implementation keeps Marketplace data outside the UI markup, allowing the catalogue to be replaced with an API without changing the core screen logic.

## Technology stack

- **Expo** and **React Native** for the mobile/web application.
- **Expo Router** for application routing.
- **TypeScript** for type-safe product and EMI data.
- **React state** for the local view, selection, loading, filtering, and cart behaviour.
- **Vitest** for data-level automated tests.

## Getting started

### Prerequisites

- [Node.js](https://nodejs.org/) 20 or later.
- [pnpm](https://pnpm.io/) 9 or later.
- An Android emulator/device with Expo Go for Android preview, or a modern web browser for the web preview.

### Install dependencies

```bash
pnpm install
```

### Start the development environment

```bash
pnpm dev
```

This starts the configured development services and opens the Expo web experience on the configured port.

### Run on Android

```bash
pnpm android
```

With the development server running, you can also scan the Expo QR code from a compatible device.

### Run the web preview only

```bash
pnpm dev:metro
```

## Validation

Run the following before submitting changes:

```bash
pnpm check
pnpm test
pnpm lint
```

- `pnpm check` runs TypeScript without emitting build output.
- `pnpm test` checks that every product has usable pricing, variants, EMI plans, and a valid catalogue-loading result.
- `pnpm lint` runs the Expo lint configuration.

## Manual test checklist

- [ ] All three Shop tiles open their expected destinations.
- [ ] Top Brands and Nearby Stores display a placeholder and return to Shop.
- [ ] Marketplace products appear after the loading state.
- [ ] Searching by product, merchant, or category narrows the visible products.
- [ ] Category chips filter the catalogue; **All** restores every product.
- [ ] Opening a product shows price, variants, and EMI options.
- [ ] Selecting an EMI plan changes the finance summary.
- [ ] Continuing with a plan adds that product to the cart.
- [ ] Cart badge, quantity changes, item removal, and subtotal update correctly.
- [ ] Empty cart and no-results states are readable and usable.

## Data model

`lib/marketplace-data.ts` defines shared types used by all Marketplace views:

```ts
type MarketplaceProduct = {
  id: string;
  title: string;
  category: string;
  merchant: string;
  description: string;
  price: number;
  compareAtPrice: number;
  imageUrl: string;
  variants: MarketplaceVariant[];
  emiPlans: EmiPlan[];
};
```

`fetchMarketplaceProducts()` currently returns this local catalogue asynchronously to exercise loading and error-capable screen logic. A production implementation can replace it with an authenticated API request while retaining the same data contract.

## Scope and intentional limitations

This is a front-end prototype. To keep the assignment deterministic and safe, these production features are intentionally outside its scope:

- Authentication and user profile data
- Live inventory, merchant pricing, and delivery estimates
- Eligibility calculations and loan/credit decisions
- Payment processing and checkout submission
- Order creation, order history, and notification delivery
- Cart persistence between app launches

The cart is stored only in React component state for the current app session. Product imagery is loaded from public image URLs; all commerce state and catalogue values are local mock data.

## Handoff notes

The submission archive excludes generated dependencies and caches. After cloning or extracting, run `pnpm install` before running the project. No environment variables or external service credentials are necessary for the Marketplace prototype.
