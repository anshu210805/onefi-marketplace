# Project TODO

- [x] Inspect the 1Fi Android reference UI and document relevant Shop patterns
- [x] Add Shop navigation with Top Brands, Nearby Stores, and 1Fi Marketplace options
- [x] Add blank placeholder screens for Top Brands and Nearby Stores
- [x] Build 1Fi Marketplace discovery screen with search, categories, promo area, and product list
- [x] Build Marketplace product detail flow
- [x] Build local cart flow with quantity controls and subtotal
- [x] Match the 1Fi-inspired visual system and accessibility touch targets
- [x] Add app branding and update mobile configuration
- [x] Run type checking and tests
- [ ] Verify the key flows in the mobile preview
- [ ] Save final project checkpoint

- [x] Add product listing with product image, name, pricing, and relevant details
- [x] Add product variants and selected-variant state
- [x] Add EMI options/plans and selected-plan state
- [x] Add CTA to proceed with the selected EMI plan
- [x] Move product and EMI information into reusable mock data structures outside UI markup
- [x] Add loading and error states for Marketplace data handling
- [x] Add responsive behavior and reusable Marketplace components
- [x] Add assignment-specific validation for data/API handling and navigation completeness

- [x] Create a GitHub-ready ZIP archive excluding dependencies, caches, and temporary build files
