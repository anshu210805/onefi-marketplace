export type MarketplaceVariant = {
  id: string;
  label: string;
  value: string;
};

export type EmiPlan = {
  id: string;
  months: number;
  monthlyAmount: number;
  interestLabel: string;
};

export type MarketplaceProduct = {
  id: string;
  title: string;
  category: string;
  merchant: string;
  description: string;
  price: number;
  compareAtPrice: number;
  imageUrl: string;
  icon: string;
  tint: string;
  surface: string;
  variants: MarketplaceVariant[];
  emiPlans: EmiPlan[];
};

export const MARKETPLACE_CATEGORIES = ["All", "Electronics", "Mobility", "Home", "Accessories", "Lifestyle"];

export const MARKETPLACE_PRODUCTS: MarketplaceProduct[] = [
  {
    id: "phone",
    title: "Smartphones",
    category: "Electronics",
    merchant: "Partner electronics",
    description: "Explore current smartphone options from participating merchants.",
    price: 24999,
    compareAtPrice: 27999,
    imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80",
    icon: "smartphone",
    tint: "#6D35D6",
    surface: "#F0EAFF",
    variants: [{ id: "black", label: "Colour", value: "Midnight" }, { id: "128", label: "Storage", value: "128 GB" }],
    emiPlans: [{ id: "phone-3", months: 3, monthlyAmount: 8333, interestLabel: "No Cost EMI" }, { id: "phone-6", months: 6, monthlyAmount: 4167, interestLabel: "No Cost EMI" }],
  },
  {
    id: "laptop",
    title: "Laptops & tablets",
    category: "Electronics",
    merchant: "Partner electronics",
    description: "Browse work, study, and everyday computing options.",
    price: 54999,
    compareAtPrice: 59999,
    imageUrl: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80",
    icon: "laptop-mac",
    tint: "#0F766E",
    surface: "#E7F7F4",
    variants: [{ id: "silver", label: "Colour", value: "Silver" }, { id: "512", label: "Storage", value: "512 GB SSD" }],
    emiPlans: [{ id: "laptop-6", months: 6, monthlyAmount: 9167, interestLabel: "No Cost EMI" }, { id: "laptop-9", months: 9, monthlyAmount: 6111, interestLabel: "No Cost EMI" }],
  },
  {
    id: "bike",
    title: "Two-wheelers",
    category: "Mobility",
    merchant: "Partner mobility stores",
    description: "Find practical mobility options from nearby partners.",
    price: 89999,
    compareAtPrice: 94999,
    imageUrl: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=900&q=80",
    icon: "two-wheeler",
    tint: "#B45309",
    surface: "#FFF6DE",
    variants: [{ id: "red", label: "Colour", value: "Crimson" }, { id: "standard", label: "Variant", value: "Standard" }],
    emiPlans: [{ id: "bike-9", months: 9, monthlyAmount: 10000, interestLabel: "No Cost EMI" }, { id: "bike-12", months: 12, monthlyAmount: 7500, interestLabel: "No Cost EMI" }],
  },
  {
    id: "home",
    title: "Home essentials",
    category: "Home",
    merchant: "Partner home stores",
    description: "Discover useful products for your everyday home setup.",
    price: 12999,
    compareAtPrice: 14999,
    imageUrl: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=80",
    icon: "chair",
    tint: "#C2410C",
    surface: "#FFF0E9",
    variants: [{ id: "oak", label: "Finish", value: "Oak" }, { id: "single", label: "Size", value: "Single" }],
    emiPlans: [{ id: "home-3", months: 3, monthlyAmount: 4333, interestLabel: "No Cost EMI" }, { id: "home-6", months: 6, monthlyAmount: 2167, interestLabel: "No Cost EMI" }],
  },
  {
    id: "audio",
    title: "Audio & accessories",
    category: "Accessories",
    merchant: "Partner electronics",
    description: "Shop headphones, speakers, and everyday accessories.",
    price: 4999,
    compareAtPrice: 5999,
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",
    icon: "headphones",
    tint: "#2563EB",
    surface: "#EAF2FF",
    variants: [{ id: "black", label: "Colour", value: "Black" }],
    emiPlans: [{ id: "audio-3", months: 3, monthlyAmount: 1667, interestLabel: "No Cost EMI" }],
  },
  {
    id: "fitness",
    title: "Fitness gear",
    category: "Lifestyle",
    merchant: "Partner lifestyle stores",
    description: "Choose equipment and accessories for active routines.",
    price: 6999,
    compareAtPrice: 7999,
    imageUrl: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=900&q=80",
    icon: "fitness-center",
    tint: "#BE185D",
    surface: "#FCEAF3",
    variants: [{ id: "home-kit", label: "Kit", value: "Home essentials" }],
    emiPlans: [{ id: "fitness-3", months: 3, monthlyAmount: 2333, interestLabel: "No Cost EMI" }, { id: "fitness-6", months: 6, monthlyAmount: 1167, interestLabel: "No Cost EMI" }],
  },
];

export async function fetchMarketplaceProducts(): Promise<MarketplaceProduct[]> {
  await new Promise((resolve) => setTimeout(resolve, 550));
  return MARKETPLACE_PRODUCTS;
}
