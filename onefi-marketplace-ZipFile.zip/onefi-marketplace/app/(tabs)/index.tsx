import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useEffect, useMemo, useState } from "react";
import {
  FlatList,
  Image,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import {
  fetchMarketplaceProducts,
  MARKETPLACE_CATEGORIES,
  type EmiPlan,
  type MarketplaceProduct,
  type MarketplaceVariant,
} from "@/lib/marketplace-data";

const COLORS = {
  canvas: "#F7F8FA",
  surface: "#FFFFFF",
  ink: "#111827",
  muted: "#6B7280",
  border: "#E5E7EB",
  purple: "#6D35D6",
  purpleSoft: "#F0EAFF",
  green: "#20B15A",
  greenSoft: "#EAF8EF",
};

type ViewName = "shop" | "marketplace" | "placeholder" | "detail" | "cart";
type LoadStatus = "idle" | "loading" | "loaded" | "error";

const money = (value: number) => `₹${value.toLocaleString("en-IN")}`;

function triggerLightHaptic() {
  if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

export default function ShopScreen() {
  const [view, setView] = useState<ViewName>("shop");
  const [placeholderTitle, setPlaceholderTitle] = useState("");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [products, setProducts] = useState<MarketplaceProduct[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<MarketplaceProduct | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<MarketplaceVariant | null>(null);
  const [selectedEmi, setSelectedEmi] = useState<EmiPlan | null>(null);
  const [cartQuantities, setCartQuantities] = useState<Record<string, number>>({});
  const [loadStatus, setLoadStatus] = useState<LoadStatus>("idle");
  const [loadError, setLoadError] = useState<string | null>(null);

  const loadProducts = async () => {
    setLoadStatus("loading");
    setLoadError(null);
    try {
      setProducts(await fetchMarketplaceProducts());
      setLoadStatus("loaded");
    } catch {
      setLoadError("We could not load the Marketplace right now.");
      setLoadStatus("error");
    }
  };

  useEffect(() => {
    if (view === "marketplace" && loadStatus === "idle") loadProducts();
  }, [view, loadStatus]);

  const filteredProducts = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return products.filter((product) => {
      const matchesCategory = category === "All" || product.category === category;
      const matchesQuery = !normalizedQuery || `${product.title} ${product.category} ${product.merchant}`.toLowerCase().includes(normalizedQuery);
      return matchesCategory && matchesQuery;
    });
  }, [category, products, query]);

  const cartProducts = products.filter((product) => cartQuantities[product.id]);
  const cartCount = Object.values(cartQuantities).reduce((total, quantity) => total + quantity, 0);
  const cartSubtotal = cartProducts.reduce((total, product) => total + product.price * cartQuantities[product.id], 0);

  const goToShop = () => {
    Keyboard.dismiss();
    setView("shop");
    setSelectedProduct(null);
    setQuery("");
    setCategory("All");
  };

  const openPlaceholder = (title: string) => {
    triggerLightHaptic();
    setPlaceholderTitle(title);
    setView("placeholder");
  };

  const openMarketplace = () => {
    triggerLightHaptic();
    setView("marketplace");
  };

  const openProduct = (product: MarketplaceProduct) => {
    triggerLightHaptic();
    setSelectedProduct(product);
    setSelectedVariant(product.variants[0] ?? null);
    setSelectedEmi(product.emiPlans[0] ?? null);
    setView("detail");
  };

  const addToCart = (product: MarketplaceProduct) => {
    triggerLightHaptic();
    setCartQuantities((current) => ({ ...current, [product.id]: (current[product.id] ?? 0) + 1 }));
    setView("cart");
  };

  const updateCartQuantity = (productId: string, nextQuantity: number) => {
    setCartQuantities((current) => {
      const next = { ...current };
      if (nextQuantity <= 0) delete next[productId];
      else next[productId] = nextQuantity;
      return next;
    });
  };

  if (view === "placeholder") {
    return (
      <ScreenContainer containerClassName="bg-[#F7F8FA]" className="px-5">
        <SubHeader title={placeholderTitle} onBack={goToShop} />
        <View style={styles.blankState}>
          <View style={styles.blankIcon}><MaterialIcons name={placeholderTitle === "Top Brands" ? "local-offer" : "store"} size={30} color={COLORS.purple} /></View>
          <Text style={styles.blankTitle}>Coming soon</Text>
          <Text style={styles.blankCopy}>This section is reserved for a future 1Fi experience.</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (view === "detail" && selectedProduct) {
    return (
      <ScreenContainer containerClassName="bg-[#F7F8FA]" className="px-5">
        <SubHeader title="Product details" onBack={() => setView("marketplace")} cartCount={cartCount} onCart={() => setView("cart")} />
        <View style={styles.detailImageWrap}>
          <Image source={{ uri: selectedProduct.imageUrl }} style={styles.detailImage} resizeMode="cover" />
        </View>
        <Text style={styles.detailTitle}>{selectedProduct.title}</Text>
        <Text style={styles.detailMerchant}>{selectedProduct.merchant}</Text>
        <View style={styles.priceRow}><Text style={styles.currentPrice}>{money(selectedProduct.price)}</Text><Text style={styles.comparePrice}>{money(selectedProduct.compareAtPrice)}</Text><Text style={styles.saveLabel}>Partner price</Text></View>
        <Text style={styles.detailDescription}>{selectedProduct.description}</Text>
        <SelectionRow label="Product variant" items={selectedProduct.variants} selectedId={selectedVariant?.id} onSelect={setSelectedVariant} />
        <SelectionRow label="Choose an EMI plan" items={selectedProduct.emiPlans} selectedId={selectedEmi?.id} onSelect={setSelectedEmi} />
        {selectedEmi && <View style={styles.emiSummary}><MaterialIcons name="event-available" size={20} color={COLORS.green} /><View style={styles.financeTextWrap}><Text style={styles.financeTitle}>{money(selectedEmi.monthlyAmount)} / month for {selectedEmi.months} months</Text><Text style={styles.financeCopy}>{selectedEmi.interestLabel} · Final eligibility is confirmed in the live 1Fi flow.</Text></View></View>}
        <Pressable accessibilityRole="button" onPress={() => addToCart(selectedProduct)} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}><Text style={styles.primaryButtonText}>Proceed with selected plan</Text><MaterialIcons name="arrow-forward" size={20} color="#FFFFFF" /></Pressable>
      </ScreenContainer>
    );
  }

  if (view === "cart") {
    return (
      <ScreenContainer containerClassName="bg-[#F7F8FA]" className="px-5">
        <SubHeader title="Your cart" onBack={() => setView("marketplace")} />
        {cartProducts.length === 0 ? <View style={styles.blankState}><View style={styles.blankIcon}><MaterialIcons name="shopping-bag" size={30} color={COLORS.purple} /></View><Text style={styles.blankTitle}>Your cart is empty</Text><Text style={styles.blankCopy}>Add a Marketplace item to keep it here for review.</Text><Pressable onPress={() => setView("marketplace")} style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>Browse Marketplace</Text></Pressable></View> : <View style={styles.cartContent}><Text style={styles.sectionTitle}>Selected items</Text>{cartProducts.map((product) => <View key={product.id} style={styles.cartRow}><Image source={{ uri: product.imageUrl }} style={styles.cartThumb} /><View style={styles.cartInfo}><Text style={styles.cartTitle}>{product.title}</Text><Text style={styles.cartMeta}>{money(product.price)} · EMI plan selected</Text><Text style={styles.cartMeta}>{product.merchant}</Text><View style={styles.quantityRow}><Pressable accessibilityRole="button" accessibilityLabel={`Decrease quantity of ${product.title}`} onPress={() => updateCartQuantity(product.id, cartQuantities[product.id] - 1)} style={styles.quantityButton}><MaterialIcons name="remove" size={17} color={COLORS.purple} /></Pressable><Text style={styles.quantityText}>{cartQuantities[product.id]}</Text><Pressable accessibilityRole="button" accessibilityLabel={`Increase quantity of ${product.title}`} onPress={() => updateCartQuantity(product.id, cartQuantities[product.id] + 1)} style={styles.quantityButton}><MaterialIcons name="add" size={17} color={COLORS.purple} /></Pressable></View></View><Pressable accessibilityRole="button" accessibilityLabel={`Remove ${product.title}`} onPress={() => updateCartQuantity(product.id, 0)} style={styles.removeButton}><MaterialIcons name="close" size={19} color={COLORS.muted} /></Pressable></View>)}<View style={styles.subtotalRow}><Text style={styles.subtotalLabel}>Subtotal</Text><Text style={styles.subtotalValue}>{money(cartSubtotal)}</Text></View><View style={styles.cartCallout}><MaterialIcons name="info-outline" size={19} color={COLORS.purple} /><Text style={styles.cartCalloutText}>This prototype stops before checkout. Eligibility and final terms would be confirmed in the live 1Fi flow.</Text></View></View>}
      </ScreenContainer>
    );
  }

  if (view === "marketplace") {
    return (
      <ScreenContainer containerClassName="bg-[#F7F8FA]" className="px-5">
        <View style={styles.subHeader}><Pressable accessibilityRole="button" accessibilityLabel="Back to Shop" onPress={goToShop} style={styles.iconButton}><MaterialIcons name="arrow-back" size={22} color={COLORS.ink} /></Pressable><View style={styles.marketplaceTitleWrap}><Text style={styles.subHeaderTitle}>1Fi Marketplace</Text><Text style={styles.headerEyebrow}>Partner shopping, made simpler</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Open cart" onPress={() => setView("cart")} style={styles.cartButton}><MaterialIcons name="shopping-bag" size={21} color={COLORS.ink} />{cartCount > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{cartCount}</Text></View>}</Pressable></View>
        <FlatList data={filteredProducts} keyExtractor={(item) => item.id} numColumns={2} columnWrapperStyle={styles.productColumns} contentContainerStyle={styles.marketplaceList} keyboardShouldPersistTaps="handled" ListHeaderComponent={<MarketplaceHeader query={query} setQuery={setQuery} category={category} setCategory={setCategory} />} renderItem={({ item }) => <ProductCard item={item} onPress={() => openProduct(item)} />} ListEmptyComponent={loadStatus === "loading" ? <LoadingState /> : loadError ? <ErrorState message={loadError} onRetry={loadProducts} /> : <View style={styles.noResults}><MaterialIcons name="search-off" size={28} color={COLORS.muted} /><Text style={styles.noResultsTitle}>No matching products</Text><Text style={styles.noResultsCopy}>Try a different category or search term.</Text></View>} />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-[#F7F8FA]" className="px-5">
      <View style={styles.shopHeader}><View><Text style={styles.brandEyebrow}>1Fi</Text><Text style={styles.shopTitle}>Shop</Text><Text style={styles.shopSubtitle}>Choose how you want to explore.</Text></View><View style={styles.headerPill}><MaterialIcons name="account-balance-wallet" size={18} color={COLORS.purple} /><Text style={styles.headerPillText}>1Fi</Text></View></View>
      <View style={styles.shopHero}><View style={styles.heroOrb}><MaterialIcons name="shopping-bag" size={34} color="#FFFFFF" /></View><View style={styles.heroCopy}><Text style={styles.heroTitle}>Shop with more clarity</Text><Text style={styles.heroBody}>Browse partner-led shopping experiences, designed around your 1Fi limit.</Text></View></View>
      <Text style={styles.sectionTitle}>Explore Shop</Text><Text style={styles.sectionSubtitle}>Pick an experience to continue</Text>
      <View style={styles.destinationList}><Destination icon="local-offer" iconBg="#F1ECFF" iconColor={COLORS.purple} title="Top Brands" subtitle="Explore popular partner brands" onPress={() => openPlaceholder("Top Brands")} /><Destination icon="store" iconBg="#E7F7F4" iconColor="#0F766E" title="Nearby Stores" subtitle="Find shopping options around you" onPress={() => openPlaceholder("Nearby Stores")} /><Destination icon="storefront" iconBg="#DFF7E8" iconColor={COLORS.green} title="1Fi Marketplace" subtitle="Browse products from partner stores" label="NEW" highlighted onPress={openMarketplace} /></View>
      <View style={styles.shopFootnote}><MaterialIcons name="verified-user" size={18} color={COLORS.green} /><Text style={styles.shopFootnoteText}>Your 1Fi shopping journey stays simple and transparent.</Text></View>
    </ScreenContainer>
  );
}

function SubHeader({ title, onBack, cartCount, onCart }: { title: string; onBack: () => void; cartCount?: number; onCart?: () => void }) {
  return <View style={styles.subHeader}><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={onBack} style={styles.iconButton}><MaterialIcons name="arrow-back" size={22} color={COLORS.ink} /></Pressable><Text style={styles.subHeaderTitle}>{title}</Text>{onCart ? <Pressable accessibilityRole="button" accessibilityLabel="Open cart" onPress={onCart} style={styles.cartButton}><MaterialIcons name="shopping-bag" size={21} color={COLORS.ink} />{cartCount ? <View style={styles.badge}><Text style={styles.badgeText}>{cartCount}</Text></View> : null}</Pressable> : <View style={styles.headerSpacer} />}</View>;
}

function Destination({ icon, iconBg, iconColor, title, subtitle, label, highlighted, onPress }: { icon: keyof typeof MaterialIcons.glyphMap; iconBg: string; iconColor: string; title: string; subtitle: string; label?: string; highlighted?: boolean; onPress: () => void }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.destinationCard, highlighted && styles.marketplaceDestination, pressed && styles.pressed]}><View style={[styles.destinationIcon, { backgroundColor: iconBg }]}><MaterialIcons name={icon} size={23} color={iconColor} /></View><View style={styles.destinationCopy}><View style={styles.marketplaceLabelRow}><Text style={styles.destinationTitle}>{title}</Text>{label && <Text style={styles.newLabel}>{label}</Text>}</View><Text style={styles.destinationSubtitle}>{subtitle}</Text></View><MaterialIcons name="chevron-right" size={24} color={highlighted ? COLORS.green : COLORS.muted} /></Pressable>;
}

function MarketplaceHeader({ query, setQuery, category, setCategory }: { query: string; setQuery: (value: string) => void; category: string; setCategory: (value: string) => void }) {
  return <View><View style={styles.searchBox}><MaterialIcons name="search" size={21} color={COLORS.muted} /><TextInput value={query} onChangeText={setQuery} placeholder="Search products or categories" placeholderTextColor={COLORS.muted} style={styles.searchInput} returnKeyType="search" />{query.length > 0 && <Pressable onPress={() => setQuery("")}><MaterialIcons name="close" size={19} color={COLORS.muted} /></Pressable>}</View><FlatList data={MARKETPLACE_CATEGORIES} horizontal showsHorizontalScrollIndicator={false} keyExtractor={(item) => item} contentContainerStyle={styles.chipsRow} renderItem={({ item }) => <Pressable onPress={() => setCategory(item)} style={[styles.chip, category === item && styles.activeChip]}><Text style={[styles.chipText, category === item && styles.activeChipText]}>{item}</Text></Pressable>} /><View style={styles.promoCard}><View style={styles.promoCopy}><Text style={styles.promoKicker}>SHOP SMARTER</Text><Text style={styles.promoTitle}>Browse partner products with 1Fi</Text><Text style={styles.promoBody}>Choose a product, review its EMI options, and continue with a selected plan.</Text></View><View style={styles.promoIcon}><MaterialIcons name="bolt" size={32} color="#FFFFFF" /></View></View><View style={styles.sectionHeadingRow}><View><Text style={styles.sectionTitle}>Featured categories</Text><Text style={styles.sectionSubtitle}>Start with something you need</Text></View><Text style={styles.catalogueLabel}>Mock catalogue</Text></View></View>;
}

function ProductCard({ item, onPress }: { item: MarketplaceProduct; onPress: () => void }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={`Open ${item.title}`} onPress={onPress} style={({ pressed }) => [styles.productCard, pressed && styles.productPressed]}><Image source={{ uri: item.imageUrl }} style={styles.productVisual} resizeMode="cover" /><View style={styles.productInfo}><Text style={styles.productTitle}>{item.title}</Text><Text style={styles.productMeta}>{money(item.price)} · {item.category}</Text><Text style={styles.productLink}>View EMI options</Text></View></Pressable>;
}

function SelectionRow<T extends { id: string; label: string; value: string } | EmiPlan>({ label, items, selectedId, onSelect }: { label: string; items: T[]; selectedId?: string; onSelect: (item: T) => void }) {
  return <View style={styles.selectionSection}><Text style={styles.selectionLabel}>{label}</Text><View style={styles.selectionRow}>{items.map((item) => { const text = "months" in item ? `${item.months} months · ${money(item.monthlyAmount)}/mo` : `${item.label}: ${item.value}`; return <Pressable key={item.id} onPress={() => onSelect(item)} style={[styles.selectionPill, selectedId === item.id && styles.selectedPill]}><Text style={[styles.selectionText, selectedId === item.id && styles.selectedPillText]}>{text}</Text></Pressable>; })}</View></View>;
}

function LoadingState() { return <View style={styles.stateBox}><MaterialIcons name="hourglass-top" size={26} color={COLORS.purple} /><Text style={styles.noResultsTitle}>Loading Marketplace</Text><Text style={styles.noResultsCopy}>Fetching products and EMI options.</Text></View>; }
function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) { return <View style={styles.stateBox}><MaterialIcons name="error-outline" size={28} color="#B45309" /><Text style={styles.noResultsTitle}>Something went wrong</Text><Text style={styles.noResultsCopy}>{message}</Text><Pressable onPress={onRetry} style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>Try again</Text></Pressable></View>; }

const styles = StyleSheet.create({
  shopHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", paddingTop: 10, paddingBottom: 22 },
  brandEyebrow: { fontSize: 13, fontWeight: "800", color: COLORS.purple, letterSpacing: 0.5 }, shopTitle: { marginTop: 2, fontSize: 32, lineHeight: 38, fontWeight: "800", color: COLORS.ink }, shopSubtitle: { marginTop: 5, fontSize: 14, color: COLORS.muted },
  headerPill: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: COLORS.purpleSoft, borderRadius: 18, paddingHorizontal: 11, paddingVertical: 8 }, headerPillText: { fontSize: 13, fontWeight: "800", color: COLORS.purple },
  shopHero: { flexDirection: "row", alignItems: "center", backgroundColor: COLORS.purple, borderRadius: 24, padding: 18, marginBottom: 24 }, heroOrb: { width: 62, height: 62, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.18)" }, heroCopy: { flex: 1, marginLeft: 14 }, heroTitle: { fontSize: 18, lineHeight: 23, fontWeight: "800", color: "#FFFFFF" }, heroBody: { marginTop: 5, fontSize: 12.5, lineHeight: 18, color: "#EDE6FF" },
  sectionTitle: { fontSize: 18, lineHeight: 24, fontWeight: "800", color: COLORS.ink }, sectionSubtitle: { marginTop: 3, fontSize: 13, color: COLORS.muted }, destinationList: { gap: 11, marginTop: 14 }, destinationCard: { flexDirection: "row", alignItems: "center", minHeight: 82, paddingHorizontal: 14, paddingVertical: 12, borderRadius: 19, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border }, marketplaceDestination: { borderColor: "#BDECCB", backgroundColor: "#FBFFFC" }, destinationIcon: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center" }, destinationCopy: { flex: 1, marginLeft: 12 }, destinationTitle: { fontSize: 15.5, fontWeight: "800", color: COLORS.ink }, destinationSubtitle: { marginTop: 4, fontSize: 12.5, color: COLORS.muted }, marketplaceLabelRow: { flexDirection: "row", alignItems: "center", gap: 7 }, newLabel: { fontSize: 9, fontWeight: "900", color: COLORS.green, backgroundColor: COLORS.greenSoft, borderRadius: 5, paddingHorizontal: 5, paddingVertical: 2 }, shopFootnote: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 22, paddingHorizontal: 5 }, shopFootnoteText: { flex: 1, fontSize: 12, lineHeight: 17, color: COLORS.muted },
  subHeader: { flexDirection: "row", alignItems: "center", minHeight: 54, paddingTop: 4, paddingBottom: 10 }, subHeaderTitle: { flex: 1, textAlign: "center", fontSize: 17, fontWeight: "800", color: COLORS.ink }, headerEyebrow: { marginTop: 2, fontSize: 10.5, color: COLORS.muted, textAlign: "center" }, marketplaceTitleWrap: { flex: 1, alignItems: "center" }, headerSpacer: { width: 42 }, iconButton: { width: 42, height: 42, alignItems: "center", justifyContent: "center" }, cartButton: { width: 42, height: 42, alignItems: "center", justifyContent: "center", position: "relative" }, badge: { position: "absolute", top: 4, right: 1, minWidth: 17, height: 17, borderRadius: 9, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.green, borderWidth: 2, borderColor: COLORS.canvas }, badgeText: { fontSize: 9, lineHeight: 12, fontWeight: "900", color: "#FFFFFF" },
  searchBox: { flexDirection: "row", alignItems: "center", backgroundColor: COLORS.surface, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 13, minHeight: 50 }, searchInput: { flex: 1, marginLeft: 9, paddingVertical: 0, fontSize: 13.5, color: COLORS.ink }, chipsRow: { gap: 8, paddingVertical: 14 }, chip: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 15, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border }, activeChip: { backgroundColor: COLORS.purple, borderColor: COLORS.purple }, chipText: { fontSize: 12, fontWeight: "700", color: COLORS.muted }, activeChipText: { color: "#FFFFFF" },
  promoCard: { flexDirection: "row", alignItems: "center", backgroundColor: COLORS.purple, borderRadius: 22, padding: 16, marginBottom: 21 }, promoCopy: { flex: 1, paddingRight: 10 }, promoKicker: { fontSize: 10, fontWeight: "900", letterSpacing: 1.1, color: "#DCCFFF" }, promoTitle: { marginTop: 6, fontSize: 17, lineHeight: 22, fontWeight: "800", color: "#FFFFFF" }, promoBody: { marginTop: 5, fontSize: 11.5, lineHeight: 16, color: "#EDE6FF" }, promoIcon: { width: 54, height: 54, borderRadius: 18, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.18)" }, sectionHeadingRow: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 12 }, catalogueLabel: { fontSize: 11, color: COLORS.muted, paddingBottom: 2 }, marketplaceList: { paddingBottom: 30 }, productColumns: { gap: 11 }, productCard: { flex: 1, minWidth: 0, backgroundColor: COLORS.surface, borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, overflow: "hidden", marginBottom: 11 }, productPressed: { opacity: 0.82, transform: [{ scale: 0.985 }] }, productVisual: { width: "100%", height: 120, backgroundColor: COLORS.purpleSoft }, productInfo: { padding: 10 }, productTitle: { fontSize: 13.5, lineHeight: 18, fontWeight: "800", color: COLORS.ink }, productMeta: { marginTop: 4, fontSize: 11, color: COLORS.muted }, productLink: { marginTop: 8, fontSize: 11.5, fontWeight: "800", color: COLORS.purple },
  stateBox: { alignItems: "center", paddingTop: 36, paddingHorizontal: 24 }, noResults: { alignItems: "center", paddingTop: 30, paddingHorizontal: 24 }, noResultsTitle: { marginTop: 10, fontSize: 15, fontWeight: "800", color: COLORS.ink }, noResultsCopy: { marginTop: 5, fontSize: 12, lineHeight: 18, textAlign: "center", color: COLORS.muted }, blankState: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 35, paddingBottom: 90 }, blankIcon: { width: 70, height: 70, borderRadius: 24, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.purpleSoft }, blankTitle: { marginTop: 18, fontSize: 21, fontWeight: "800", color: COLORS.ink }, blankCopy: { marginTop: 7, fontSize: 13, lineHeight: 19, textAlign: "center", color: COLORS.muted }, secondaryButton: { marginTop: 18, borderRadius: 16, borderWidth: 1, borderColor: COLORS.purple, paddingHorizontal: 16, paddingVertical: 12 }, secondaryButtonText: { fontSize: 13, fontWeight: "800", color: COLORS.purple },
  detailImageWrap: { height: 232, borderRadius: 26, overflow: "hidden", backgroundColor: COLORS.purpleSoft, marginTop: 8 }, detailImage: { width: "100%", height: "100%" }, detailTitle: { marginTop: 20, fontSize: 27, lineHeight: 33, fontWeight: "900", color: COLORS.ink }, detailMerchant: { marginTop: 6, fontSize: 13, color: COLORS.muted }, priceRow: { flexDirection: "row", alignItems: "center", gap: 9, marginTop: 11 }, currentPrice: { fontSize: 19, fontWeight: "900", color: COLORS.ink }, comparePrice: { fontSize: 12.5, color: COLORS.muted, textDecorationLine: "line-through" }, saveLabel: { fontSize: 10, fontWeight: "800", color: COLORS.green, backgroundColor: COLORS.greenSoft, paddingHorizontal: 6, paddingVertical: 3, borderRadius: 5 }, detailDescription: { marginTop: 14, fontSize: 13.5, lineHeight: 20, color: COLORS.muted }, selectionSection: { marginTop: 18 }, selectionLabel: { fontSize: 13, fontWeight: "800", color: COLORS.ink }, selectionRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 9 }, selectionPill: { paddingHorizontal: 11, paddingVertical: 9, borderRadius: 13, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border }, selectedPill: { backgroundColor: COLORS.purpleSoft, borderColor: COLORS.purple }, selectionText: { fontSize: 11.5, color: COLORS.muted }, selectedPillText: { fontWeight: "800", color: COLORS.purple }, emiSummary: { flexDirection: "row", alignItems: "center", marginTop: 18, padding: 13, borderRadius: 16, backgroundColor: COLORS.greenSoft }, financeTextWrap: { flex: 1, marginLeft: 10 }, financeTitle: { fontSize: 13, fontWeight: "800", color: COLORS.ink }, financeCopy: { marginTop: 3, fontSize: 11, lineHeight: 16, color: COLORS.muted }, primaryButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, minHeight: 52, marginTop: 20, borderRadius: 17, backgroundColor: COLORS.purple }, primaryButtonText: { fontSize: 14, fontWeight: "900", color: "#FFFFFF" }, pressed: { opacity: 0.86, transform: [{ scale: 0.985 }] },
  cartContent: { paddingTop: 12 }, cartRow: { flexDirection: "row", alignItems: "center", paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: COLORS.border }, cartThumb: { width: 56, height: 56, borderRadius: 15, backgroundColor: COLORS.purpleSoft }, cartInfo: { flex: 1, marginLeft: 12 }, cartTitle: { fontSize: 14, fontWeight: "800", color: COLORS.ink }, cartMeta: { marginTop: 3, fontSize: 11.5, color: COLORS.muted }, quantityRow: { flexDirection: "row", alignItems: "center", gap: 9, marginTop: 9 }, quantityButton: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.purpleSoft }, quantityText: { minWidth: 15, textAlign: "center", fontSize: 13, fontWeight: "800", color: COLORS.ink }, removeButton: { width: 34, height: 34, alignItems: "center", justifyContent: "center" }, subtotalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 18 }, subtotalLabel: { fontSize: 15, fontWeight: "800", color: COLORS.ink }, subtotalValue: { fontSize: 17, fontWeight: "900", color: COLORS.ink }, cartCallout: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 22, padding: 14, borderRadius: 17, backgroundColor: COLORS.purpleSoft }, cartCalloutText: { flex: 1, fontSize: 11.5, lineHeight: 17, color: COLORS.muted },
});
