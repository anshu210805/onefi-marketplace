# 1Fi Reference UI Findings

Source: https://play.google.com/store/apps/details?id=in.onefi.app&pcampaignid=web_share

The public Play Store listing shows a finance app branded with a vivid purple 1Fi icon and a clean, white interface. The visible app screenshots use rounded purple cards, large white numeric typography, compact status and payment summaries, and a calm light background. Primary actions are presented in rounded pill-like controls, with purple used as the dominant accent and dark navy/charcoal used for headings.

The product positioning is financing-backed shopping: eligibility, pledged mutual funds, spending limit, no-cost EMI, and partner merchant purchases. The new Shop flow should therefore feel like an extension of a finance product rather than a generic marketplace. Marketplace copy should emphasize simple browsing and financing context without inventing live offers, stock counts, or payment values.

The assignment requires three Shop options: Top Brands, Nearby Stores, and 1Fi Marketplace. Top Brands and Nearby Stores should be navigable blank placeholder pages. 1Fi Marketplace should be the fully implemented route, with local deterministic content for discovery, product details, and cart interactions.

Design direction for the prototype: light neutral canvas, purple 1Fi-inspired accent, rounded white surfaces, soft gray borders, strong hierarchy, concise labels, large tap targets, and a simple bottom-tab context. Keep the UI calm and product-led, not overly colorful or crowded.
