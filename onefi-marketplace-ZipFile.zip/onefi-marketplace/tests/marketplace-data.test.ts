import { describe, expect, it } from "vitest";

import { MARKETPLACE_PRODUCTS, fetchMarketplaceProducts } from "../lib/marketplace-data";

describe("Marketplace data", () => {
  it("contains products with pricing, variants, and EMI plans", () => {
    expect(MARKETPLACE_PRODUCTS.length).toBeGreaterThan(0);
    for (const product of MARKETPLACE_PRODUCTS) {
      expect(product.imageUrl).toMatch(/^https:\/\//);
      expect(product.price).toBeGreaterThan(0);
      expect(product.variants.length).toBeGreaterThan(0);
      expect(product.emiPlans.length).toBeGreaterThan(0);
      expect(product.emiPlans[0].monthlyAmount).toBeGreaterThan(0);
    }
  });

  it("returns the same reusable catalogue through the data function", async () => {
    await expect(fetchMarketplaceProducts()).resolves.toHaveLength(MARKETPLACE_PRODUCTS.length);
  });
});
